
python -m venv env
```
env\Scripts\activate
```



```bash
pip install -r requirements.txt
```


```bash
pip install -r requirements.txt --use-deprecated=legacy-resolver
```

```bash
python manage.py makemigrations
```

```bash
python manage.py migrate
```


```bash
python manage.py createsuperuser
```



```bash
python manage.py runserver
```

Now the project should be running on http://127.0.0.1:8000/

Login as admin and add some courses, teacher and students.



